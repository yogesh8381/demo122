package com.example.jwtdecryptor;

import com.example.jwtdecryptor.model.JwtPayload;
import com.example.jwtdecryptor.service.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class JwtController {

    @Autowired
    private JwtService jwtService;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @PostMapping("/decrypt")
    public String decryptToken(@RequestParam(required = false) String token, Model model) {
        if (token == null || token.isEmpty()) {
            model.addAttribute("error", "JWT token must not be empty.");
            return "index";
        }

        try {
            JwtPayload jwtPayload = jwtService.decryptToken(token);
            model.addAttribute("header", jwtPayload.getHeader());
            model.addAttribute("claims", jwtPayload.getClaims());
            return "decrypt";
        } catch (Exception e) {
            model.addAttribute("error", "Invalid JWT token: " + e.getMessage());
            return "index";
        }
    }

    @ExceptionHandler(Exception.class)
    public ModelAndView handleError(Exception ex) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("error", "An unexpected error occurred: " + ex.getMessage());
        mav.setViewName("index");
        return mav;
    }
}
